# Wiggly Talking Fish News Format Kit

Open `v3/SKILL.md` if you are an agent.
Open `v3/public/format-repositories/talking-fish-news-v1/README.md` for the human quick start.
Run commands from the `v3` directory.
