export { talkingFishNewsProofScene as defaultRenderScene } from "../features/formats/talking-fish-news/fixture";
