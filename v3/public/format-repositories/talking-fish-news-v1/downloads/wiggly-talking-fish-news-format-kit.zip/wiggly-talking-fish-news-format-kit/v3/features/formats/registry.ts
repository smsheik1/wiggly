import type { RenderableAdFormatId } from "../scene/types";
import type { AdFormatModule } from "./types";
import { talkingFishNewsFormatModule } from "./talking-fish-news";

export const getFormatModule = (format: RenderableAdFormatId): AdFormatModule => {
  if (format !== "talking-fish-news") throw new Error(`Unknown ad format: ${format}`);
  return talkingFishNewsFormatModule as AdFormatModule;
};
