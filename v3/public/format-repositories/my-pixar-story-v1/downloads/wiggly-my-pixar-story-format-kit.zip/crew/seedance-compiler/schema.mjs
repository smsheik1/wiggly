// Seedance Compiler v2 output contract (Zod, plain JS). Mirrors the other v2 crew contracts.
import { z } from 'zod';
import { ASSET_KEY } from '../character-architect/schema.mjs';
import { dedupeLookLines } from './look-dedupe.mjs';
import { SPOKEN_SPELLINGS } from '../../config/spoken-spellings.mjs';

export const VIDEO_ENGINE = 'seedance-2.5';
export const VIDEO_RESOLUTION = '480p';
export const MAX_SEGMENT_SECONDS = 30;
// WIGGLY: target video engines. segmentMaxSec = longest clip the engine renders; durations = the clip lengths it offers
// (null = any whole second up to the cap). A staged part longer than the cap is split into clips at shot boundaries.
export const VIDEO_ENGINES = Object.freeze({
  // Replicate bytedance/seedance-2.5 (latest version checked 2026-10-21): duration 4-30s, no prompt maxLength, up to 30 reference_images
  // ([ImageN]); reference_audios exist but drive lip-sync, so narration is voiced in-render from the quoted line instead (no [AudioN]).
  // generate_audio voices "double-quoted" dialogue. Each clip is self-contained (continuation 'cut'): a clip can be re-rendered alone.
  'seedance-2.5': Object.freeze({ provider: 'replicate', model: 'bytedance/seedance-2.5', segmentMaxSec: 30, durations: null, continuation: 'cut', maxRefImages: 30, quotes: 'double', narrationAudioRef: false }),
  // Replicate bytedance/seedance-2.0-mini (checked 2026-10-20): duration 4-15s any whole second, prompt max 4000 chars, up to 9 reference images.
  // promptMaxChars is the cap on the prompt as SENT, i.e. after sendTimeTags() adds [ImageN] / [AudioN]; PROMPT_TOO_LONG counts those tags.
  'seedance-2.0-mini': Object.freeze({ provider: 'replicate', model: 'bytedance/seedance-2.0-mini', segmentMaxSec: 15, durations: null, promptMaxChars: 4000, continuation: 'cut', maxRefImages: 9, narrationAudioRef: true }),
  // Replicate alibaba/wan-3 (checked 2026-10-21): duration 2-30s, prompt + optional first-frame image only on the hosted endpoint
  // (no reference_images input, no audio switch). The adapter still writes refs as 'Image N' and caps them at 10 for a
  // reference-to-video endpoint (1 character + 2 backgrounds + 7 panels).
  'wan-3.0': Object.freeze({ provider: 'replicate', model: 'alibaba/wan-3', segmentMaxSec: 30, durations: null, continuation: 'cut', maxRefImages: 10, quotes: 'double', narrationAudioRef: false, refLabel: 'spaced' }),
  'omni-1.1-flash': Object.freeze({ provider: 'google-flow', segmentMaxSec: 10, durations: Object.freeze([4, 6, 8, 10]), continuation: 'cut', postNarration: true /* narration is TTS laid in post; Omni voices any words it is given */ }),
});
export const ENGINE_IDS = Object.keys(VIDEO_ENGINES);
/** Lessons from renders, applied to every sent prompt: brand names in their spoken spelling (config/spoken-spellings.mjs),
 *  and a bare 'coupe' outside spoken lines and tags becomes 'two-door coupe' (engines drew four doors). */
export function spokenAndPlain(text) {
  let p = String(text ?? '');
  for (const [w, sp] of Object.entries(SPOKEN_SPELLINGS)) p = p.replace(new RegExp(`\\b${reEsc(w)}\\b`, 'gi'), sp);
  return p.split(/("[^"\n]*"|\{[^}\n]*\})/).map((part, i) => (i % 2 ? part : part.replace(/(?<![\w@-])(?<!two-door )coupe\b(?!_)/gi, 'two-door coupe'))).join('');
}
const reEsc = (x) => x.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
/** The prompt exactly as sent to a reference-input engine: "[ImageN]" after each reference's "@Tag =" line (N = 1-based order of
 *  segment.references, which is the attachment order) and, for engines that take a narration audio file (narrationAudioRef),
 *  "(narration audio [Audio1][, part K])" after each voiceover line. The length gate (PROMPT_TOO_LONG) measures sendPrompt(). */
export function sendTimeTags(prompt, references = [], engine) {
  let p = String(prompt ?? '');
  references.forEach((r, i) => { p = p.replace(new RegExp(`^${reEsc(r.tag)} =`, 'm'), `${r.tag} [Image${i + 1}] =`); });
  if (engine && VIDEO_ENGINES[engine] && !VIDEO_ENGINES[engine].narrationAudioRef) return p;
  const vo = p.match(/^@[\w]+, voiceover: \{[^}]*\}/gm)?.length ?? 0; let k = 0;
  p = p.replace(/^@[\w]+, voiceover: \{[^}]*\}/gm, (m) => `${m}${vo > 1 ? ` (narration audio [Audio1], part ${++k})` : ' (narration audio [Audio1])'}`);
  return p;
}

/** Storyboard panels are NOT sent to the video engine by default (r5 clip 1: Seedance 2.5 copied the panels' blurred side
 *  bars and 2D look into the render; "composition guides only, never copy their style" does not stop a diffusion model).
 *  The video engine gets character sheets and location plates only; boards stay pre-production. Opt in per call with
 *  { storyboards: true } (or an engine flag storyboardRefs: true) for experiments only. */
export const SEND_STORYBOARDS = false;
/** Storyboard panels of a clip in shot order: [{ sceneId, shotNumber, assetKey, imageN }] after the clip's element references. */
export function panelRefs(seg, engine, { storyboards = VIDEO_ENGINES[engine]?.storyboardRefs ?? SEND_STORYBOARDS } = {}) {
  const panels = storyboards ? (seg?.storyboardPanels ?? {}) : {}, base = (seg?.references ?? []).length, out = [];
  for (const sh of seg?.shots ?? []) if (panels[sh.sceneId] && !out.some((o) => o.sceneId === sh.sceneId)) out.push({ sceneId: sh.sceneId, shotNumber: sh.shotNumber, assetKey: panels[sh.sceneId], imageN: base + out.length + 1 });
  // engine image cap: drop the panel of the shortest shot (ties: the later one) until it fits; that shot reuses the panel
  // of the shot before it (shotPanels maps every shot to the panel it is composed from)
  const cap = VIDEO_ENGINES[engine]?.maxRefImages;
  const len = (n) => { const sh = (seg?.shots ?? []).find((x) => x.shotNumber === n); return sh ? sh.endSec - sh.startSec : 0; };
  const dropped = [];
  while (cap && out.length > 1 && base + out.length > cap) {
    let k = 1; for (let i = 1; i < out.length; i++) if (len(out[i].shotNumber) <= len(out[k].shotNumber)) k = i; // never the first panel
    dropped.push(out.splice(k, 1)[0]);
  }
  out.forEach((o, i) => { o.imageN = base + i + 1; });
  out.shotPanels = Object.fromEntries((seg?.shots ?? []).map((sh) => [sh.shotNumber, [...out].reverse().find((o) => o.shotNumber <= sh.shotNumber) ?? out[0]]));
  out.dropped = dropped.map((d) => d.sceneId);
  return out;
}

/**
 * The final prompt for one clip, exactly as sent (deterministic, after the gate): reference tags, then (only when storyboards
 * are opted in, see SEND_STORYBOARDS) each shot's storyboard panel labeled "Composition from [ImageN]" under its Camera line, and on engines that voice "double-quoted" dialogue
 * the {braces} of every spoken line become "double quotes". Returns { prompt, images: [assetKey in attachment order] }.
 */
export function sendPrompt(seg, engine = seg?.generationPayload?.engine ?? VIDEO_ENGINE, opts = {}) {
  const e = VIDEO_ENGINES[engine] ?? {};
  let p = sendTimeTags(seg?.compiledPrompt, seg?.references ?? [], engine);
  const panels = panelRefs(seg, engine, opts);
  if (panels.length) {
    const first = panels[0].imageN, last = panels.at(-1).imageN;
    p = p.replace(/^(Each reference is one person[^\n]*)$/m, `$1\nStoryboard frames ${first === last ? `[Image${first}]` : `[Image${first}] to [Image${last}]`}: ${panels.dropped.length ? 'in shot order, each named on its shot' : 'one per shot'}, composition and staging guides only; never copy their drawing style, borders or labels.`);
    for (const [n, pr] of Object.entries(panels.shotPanels)) if (pr) p = p.replace(new RegExp(`(^SHOT ${n} \\|[^\n]*\n(?:Camera:[^\n]*\n)?)`, 'm'), `$1Composition from [Image${pr.imageN}].\n`);
  }
  if (e.quotes === 'double') p = p.replace(/\{([^{}]+)\}/g, '"$1"').replace(/lines in braces/g, 'lines in double quotes');
  p = spokenAndPlain(p);
  if (e.refLabel === 'spaced') p = p.replace(/\[Image(\d+)\]/g, 'Image $1');
  return { prompt: p, images: [...(seg?.references ?? []).map((r) => r.assetKey), ...panels.map((x) => x.assetKey)] };
}
/** generationPayload.durationSec for a clip: the smallest duration the engine offers that is >= the clip's true length. */
export function engineDurationFor(engine, lenSec) {
  const e = VIDEO_ENGINES[engine];
  if (!e) return undefined;
  if (!e.durations) return lenSec <= e.segmentMaxSec ? lenSec : undefined;
  return e.durations.find((d) => d >= lenSec);
}
export const MAX_TOTAL_SECONDS = 180;
export const REF_TAG = /^@(?:Image|Loc|Prop) \d+$/;
export const SLOT_TAG = /^@(?:Image|Loc|Prop)\b/i;
const ELEMENT = /^@[\w_]+$/;

export const ReferenceSchema = z.object({
  tag: z.string().regex(ELEMENT, "tag is an element name like '@Theo' or '@kitchen'").refine((t) => !SLOT_TAG.test(t), 'use element names, never @Image N / @Loc N / @Prop N slots'),
  kind: z.enum(['character', 'location', 'prop', 'staging']),
  sourceTag: z.string().regex(REF_TAG).optional().describe('Upstream slot: @Image N (Character Architect), @Loc N (Location Scout), or @Prop N (Prop Architect)'),
  assetKey: z.string().regex(ASSET_KEY, 'assetKey must be a local asset key, not a URL or file path').refine((s) => !/^https?:|\//.test(s), 'assetKey must not be a URL or path'),
}).strict()
  .refine((r) => {
    if (!r.sourceTag) return true;
    if (r.kind === 'character') return r.sourceTag.startsWith('@Image ');
    if (r.kind === 'location') return r.sourceTag.startsWith('@Loc ');
    if (r.kind === 'prop') return r.sourceTag.startsWith('@Prop ');
    return true;
  }, { message: 'character refs come from @Image N, location refs from @Loc N, prop refs from @Prop N', path: ['sourceTag'] });

export const ShotDialogueSchema = z.object({
  speaker: z.string().regex(ELEMENT),
  line: z.string().regex(/^\{.+\}$/, 'line must be enclosed in {}'),
  mode: z.enum(['on-camera', 'off-camera', 'voiceover']).default('on-camera'),
}).strict();

export const CompiledShotSchema = z.object({
  shotNumber: z.number().int().positive(),
  startSec: z.number().int().nonnegative(),
  endSec: z.number().int().positive(),
  sceneId: z.string().regex(/^\d+\.\d+$/),
  locationTag: z.string().regex(ELEMENT),
  cast: z.array(z.string().regex(ELEMENT)).default([]),
  action: z.string().min(10),
  dialogue: ShotDialogueSchema.optional(),
  sfx: z.array(z.string()).default([]),
  cut: z.literal('Hard cut.').default('Hard cut.'),
}).strict().refine((s) => s.endSec > s.startSec, { message: 'endSec must be > startSec', path: ['endSec'] });

// BASE: Gemini's per-segment object (gemini-sc-schema.md). Wiggly additions marked "WIGGLY".
export const BLOCK_HEADERS = ['[REFERENCE MATERIALS]', '[VOICES]', '[GOAL]', '[CONTINUITY]', '[SHOTS]', '[VISUAL STYLE]', '[CAMERA AND PERFORMANCE]', '[AUDIO]', '[EXCLUSIONS]', '[MAINTAIN CONSISTENCY]'];
export const BLOCK_KEYS = ['block1_referenceMaterials', 'block2_voices', 'block3_goal', 'block4_continuity', 'block5_shots', 'block6_visualStyle', 'block7_cameraAndPerformance', 'block8_audio', 'block9_exclusions', 'block10_maintainConsistency'];

export const TenBlocksSchema = z.object({
  block1_referenceMaterials: z.string().min(20),
  block2_voices: z.string().min(20),
  block3_goal: z.string().min(20),
  block4_continuity: z.string().min(20),
  block5_shots: z.string().min(50),
  block6_visualStyle: z.string().min(20),
  block7_cameraAndPerformance: z.string().min(20),
  block8_audio: z.string().min(10).refine((a) => !/[{}]/.test(a), 'block8_audio must contain zero dialogue (no { or })'),
  block9_exclusions: z.string().min(20),
  block10_maintainConsistency: z.string().min(20),
}).strict();

export const GenerationPayloadSchema = z.object({
  engine: z.enum(ENGINE_IDS).default(VIDEO_ENGINE),
  durationSec: z.number().int().min(1).max(MAX_SEGMENT_SECONDS),
  resolution: z.literal(VIDEO_RESOLUTION).default(VIDEO_RESOLUTION), // WIGGLY: 480p only
  aspectRatio: z.literal('16:9').default('16:9'),
  fps: z.number().int().default(24),
}).strict();

/** Ordered position of each header in a compiled prompt (-1 if missing). */
export const headerPositions = (text) => BLOCK_HEADERS.map((h) => text.indexOf(h));

export const SeedanceSegmentBase = z.object({
  segmentId: z.number().int().positive().describe('Stage-play segment id'),
  title: z.string().min(3),
  totalDurationSec: z.number().int().min(1).max(MAX_SEGMENT_SECONDS),
  shotCount: z.number().int().positive(),
  attachedElements: z.array(z.string().regex(ELEMENT)).min(1),
  tenBlocks: TenBlocksSchema,
  compiledPrompt: z.string().min(500),
  generationPayload: GenerationPayloadSchema,
  // WIGGLY
  segmentIndex: z.number().int().positive(),
  // Absent = first segment (null). Muse omitted it on segment 1 in r4-dry5; the chain refine still enforces 2+.
  extendsFrom: z.number().int().positive().nullable().default(null).describe('null for the first segment; otherwise the previous segmentIndex'),
  references: z.array(ReferenceSchema).min(1),
  shots: z.array(CompiledShotSchema).min(1),
  // WIGGLY clips: when a staged part is longer than the engine's clip cap it is split into consecutive clips at shot
  // boundaries. segmentId stays the source part; shots restart at 0 and keep the source sceneId.
  clipId: z.string().regex(/^\d+[a-z]$/, 'clipId is the part id plus a letter, e.g. "2a"').optional(),
  sourceShotNumbers: z.array(z.number().int().positive()).min(1).optional().describe('the staged shotNumbers this clip covers, in order'),
  sourceStartSec: z.number().int().nonnegative().default(0).describe('where this clip starts inside its staged part'),
}).strict();

export const SeedanceSegmentSchema = SeedanceSegmentBase.superRefine((seg, ctx) => {
  const pos = headerPositions(seg.compiledPrompt);
  pos.forEach((p, i) => { if (p < 0) ctx.addIssue({ code: 'custom', path: ['compiledPrompt'], message: `missing block header ${BLOCK_HEADERS[i]}` }); });
  const present = pos.filter((p) => p >= 0);
  if (present.some((p, i) => i > 0 && p < present[i - 1])) ctx.addIssue({ code: 'custom', path: ['compiledPrompt'], message: 'block headers must appear in sequential order' });
  const wantDur = engineDurationFor(seg.generationPayload.engine, seg.totalDurationSec);
  if (seg.generationPayload.durationSec !== wantDur)
    ctx.addIssue({ code: 'custom', path: ['generationPayload', 'durationSec'], message: wantDur === undefined
      ? `totalDurationSec ${seg.totalDurationSec}s is longer than ${seg.generationPayload.engine} renders (${VIDEO_ENGINES[seg.generationPayload.engine].segmentMaxSec}s): split the part into clips at shot boundaries`
      : `generationPayload.durationSec (${seg.generationPayload.durationSec}) must be ${wantDur} (${VIDEO_ENGINES[seg.generationPayload.engine].durations ? `the smallest ${seg.generationPayload.engine} duration >= the clip's ${seg.totalDurationSec}s` : `equal to totalDurationSec`})` });
  if (seg.sourceShotNumbers && seg.sourceShotNumbers.length !== seg.shots.length)
    ctx.addIssue({ code: 'custom', path: ['sourceShotNumbers'], message: `sourceShotNumbers lists ${seg.sourceShotNumbers.length} shots but the clip has ${seg.shots.length}` });
  if (seg.shotCount !== seg.shots.length) ctx.addIssue({ code: 'custom', path: ['shotCount'], message: `shotCount ${seg.shotCount} != ${seg.shots.length} shots` });
  let t = 0;
  seg.shots.forEach((s, i) => {
    if (s.shotNumber !== i + 1) ctx.addIssue({ code: 'custom', path: ['shots', i, 'shotNumber'], message: `shotNumber must be ${i + 1}` });
    if (s.startSec !== t) ctx.addIssue({ code: 'custom', path: ['shots', i, 'startSec'], message: `timecodes must be contiguous: expected startSec ${t}` });
    t = s.endSec;
  });
  if (t !== seg.totalDurationSec) ctx.addIssue({ code: 'custom', path: ['totalDurationSec'], message: `last shot ends at ${t}s but totalDurationSec is ${seg.totalDurationSec}` });
  const tags = seg.references.map((r) => r.tag);
  if (new Set(tags).size !== tags.length) ctx.addIssue({ code: 'custom', path: ['references'], message: 'duplicate reference tag' });
  for (const t2 of tags) if (!seg.attachedElements.includes(t2)) ctx.addIssue({ code: 'custom', path: ['attachedElements'], message: `reference ${t2} missing from attachedElements` });
  const castTags = new Set(seg.references.filter((r) => r.kind === 'character').map((r) => r.tag));
  const locTags = new Set(seg.references.filter((r) => r.kind === 'location').map((r) => r.tag));
  seg.shots.forEach((s, i) => {
    // Voice-over / off-camera speakers are heard, not seen: they need no picture attached to this part (r5-dry2: the
    // narrator was rejected in a part he never appears in). The gate still checks they are in the stage-play cast.
    if (s.dialogue && s.dialogue.mode === 'on-camera' && !castTags.has(s.dialogue.speaker))
      ctx.addIssue({ code: 'custom', path: ['shots', i, 'dialogue', 'speaker'], message: `speaker ${s.dialogue.speaker} speaks on camera but is not a bound cast reference (attach their picture to this part, or mark the line mode 'voiceover' / 'off-camera')` });
    if (!locTags.has(s.locationTag)) ctx.addIssue({ code: 'custom', path: ['shots', i, 'locationTag'], message: `locationTag ${s.locationTag} is not a bound location reference` });
  });
});

/** Assemble compiledPrompt in code from the 10 ordered blocks (headers can never go missing or out of order). */
export function assembleCompiledPrompt(tenBlocks = {}) {
  return BLOCK_HEADERS.map((h, i) => `${h}\n${String(tenBlocks[BLOCK_KEYS[i]] ?? '').trim()}`).join('\n\n');
}
/** Return a copy of an output object with every segment's compiledPrompt assembled from its tenBlocks. */
export function withAssembledPrompts(obj) {
  if (!obj || !Array.isArray(obj.segments)) return obj;
  return { ...obj, segments: obj.segments.map((s) => { if (!s || !s.tenBlocks) return s;
    const tb = typeof s.tenBlocks.block5_shots === 'string' ? { ...s.tenBlocks, block5_shots: dedupeLookLines(s.tenBlocks.block5_shots) } : s.tenBlocks; // Look items deduped in code
    return { ...s, tenBlocks: tb, compiledPrompt: assembleCompiledPrompt(tb) }; }) };
}
/** Submit-tool schema: same contract, but compiledPrompt is optional (code assembles it). */
export const SeedanceSubmitSchema = z.object({
  segments: z.array(SeedanceSegmentBase.extend({ compiledPrompt: z.string().optional() })).min(1),
  totalRuntimeSec: z.number().int().positive().max(MAX_TOTAL_SECONDS),
  assumptions: z.array(z.string()).default([]),
}).strict();

export const SeedanceCompilerOutputSchema = z.object({
  segments: z.array(SeedanceSegmentSchema).min(1),
  totalRuntimeSec: z.number().int().positive().max(MAX_TOTAL_SECONDS),
  assumptions: z.array(z.string()).default([]),
}).strict().superRefine((d, ctx) => {
  d.segments.forEach((s, i) => {
    if (s.segmentIndex !== i + 1) ctx.addIssue({ code: 'custom', path: ['segments', i, 'segmentIndex'], message: `segmentIndex must be ${i + 1}` });
    const want = i === 0 ? null : i;
    if (s.extendsFrom !== want) ctx.addIssue({ code: 'custom', path: ['segments', i, 'extendsFrom'], message: `extendsFrom must be ${want} (Extend chain)` });
  });
  const total = d.segments.reduce((n, s) => n + s.totalDurationSec, 0);
  if (total !== d.totalRuntimeSec) ctx.addIssue({ code: 'custom', path: ['totalRuntimeSec'], message: `totalRuntimeSec ${d.totalRuntimeSec} != sum of segments ${total}` });
});

/**
 * WIGGLY patch mode: the compiler recompiles only the parts a Story Director patch touched. Each submitted segment keeps
 * its place in the whole film (segmentIndex / extendsFrom from positions: { segmentId: segmentIndex }); requiredIds, when
 * given, must all be present and nothing else. Code then merges these segments into the prior output (graph/patch.mjs).
 */
export function makeSeedancePatchSchema(positions = {}, requiredIds) {
  return z.object({
    segments: z.array(SeedanceSegmentSchema).min(1),
    totalRuntimeSec: z.number().int().positive().max(MAX_TOTAL_SECONDS),
    assumptions: z.array(z.string()).default([]),
  }).strict().superRefine((d, ctx) => {
    const ids = d.segments.map((s) => s.segmentId);
    if (new Set(ids).size !== ids.length) ctx.addIssue({ code: 'custom', path: ['segments'], message: 'a part is compiled twice' });
    d.segments.forEach((s, i) => {
      const at = positions[s.segmentId];
      if (at === undefined) { ctx.addIssue({ code: 'custom', path: ['segments', i, 'segmentId'], message: `part ${s.segmentId} is not in this film` }); return; }
      if (requiredIds && !requiredIds.includes(s.segmentId)) ctx.addIssue({ code: 'custom', path: ['segments', i, 'segmentId'], message: `part ${s.segmentId} is not affected by the patch; compile only parts ${requiredIds.join(', ')}` });
      if (s.segmentIndex !== at) ctx.addIssue({ code: 'custom', path: ['segments', i, 'segmentIndex'], message: `segmentIndex must be ${at} (its place in the whole film)` });
      const want = at === 1 ? null : at - 1;
      if (s.extendsFrom !== want) ctx.addIssue({ code: 'custom', path: ['segments', i, 'extendsFrom'], message: `extendsFrom must be ${want} (Extend chain of the whole film)` });
    });
    for (const id of requiredIds ?? []) if (!ids.includes(id)) ctx.addIssue({ code: 'custom', path: ['segments'], message: `part ${id} is affected by the patch and must be compiled` });
    const total = d.segments.reduce((n, s) => n + s.totalDurationSec, 0);
    if (total !== d.totalRuntimeSec) ctx.addIssue({ code: 'custom', path: ['totalRuntimeSec'], message: `totalRuntimeSec ${d.totalRuntimeSec} != sum of the compiled parts ${total}` });
  });
}

export class SeedancePromptParseError extends Error {
  constructor(issues) {
    super('Seedance Compiler output failed the contract:\n' +
      issues.map((i) => `  - ${(i.path ?? []).join('.') || '(root)'}: ${i.message}`).join('\n'));
    this.name = 'SeedancePromptParseError';
    this.issues = issues;
  }
}

/** Parse Seedance Compiler output (object or JSON string). Throws SeedancePromptParseError. */
export function parseSeedancePrompts(input) {
  let obj = input;
  if (typeof input === 'string') {
    try { obj = JSON.parse(input); } catch (e) { throw new SeedancePromptParseError([{ path: [], message: `not valid JSON (${e.message})` }]); }
  }
  const r = SeedanceCompilerOutputSchema.safeParse(withAssembledPrompts(obj));
  if (!r.success) throw new SeedancePromptParseError(r.error.issues);
  return r.data;
}
