// Story Director v2 input slice: the ONLY state this agent may see.
import { z } from 'zod';

export const SCENE_KEYS = ['scene1Childhood', 'scene2TeenFreedom', 'scene3LeapOfFaith', 'scene4Romance', 'scene5LegacyFinale'];

export const StoryDirectorInput = z.object({
  subject: z.string().default(''),
  answers: z.record(z.string(), z.unknown()),
  castDescriptions: z.array(z.object({
    id: z.string(), name: z.string(), description: z.string(),
  })).default([]),
  // WIGGLY: main characters with real reference photos. Text only (no paths/bytes); use these looks, never guess.
  photoCharacters: z.array(z.object({
    id: z.string().min(1), name: z.string().min(1), realPerson: z.string().min(1),
    age: z.number().int().positive().nullable().default(null),
    skinTone: z.string().min(3), description: z.string().min(10),
  }).strict()).default([]),
  format: z.object({
    maxPartSeconds: z.number().int().max(30).default(30),
    // The target is the maximum runtime (gate: RUNTIME_OVER_TARGET at target + 5s); targetTotalRuntimeSec wins when set.
    targetTotalSeconds: z.number().int().max(180).default(90),
    narrationAllowed: z.boolean().default(true),
    dialogueAllowed: z.boolean().default(true),
  }).prefault({}),
  targetTotalRuntimeSec: z.number().int().min(20).max(180).default(90),
  settingSeed: z.string().optional(),
  voiceNoteTranscript: z.string().optional(),
  toneDirectives: z.object({
    // No default tone: a missing tone stays missing (comedy only when asked for or a memory is genuinely funny).
    genre: z.enum(['comedy-subversion', 'emotional-journey', 'character-vignette']).optional(),
    pacing: z.enum(['slow-burn', 'standard-pixar', 'rapid-fire']).optional(),
    runningGagSeed: z.string().optional(),
  }).strict().optional(),
}).strict();

/** The family's story direction: copied from the project input to the graph inputs and into the Story Director input.
 * One list for every entry point (scripts/run-rehearsal.mjs inputsFromProject) so a field cannot be dropped on the way. */
export const STORY_DIRECTION_KEYS = ['targetTotalRuntimeSec', 'settingSeed', 'voiceNoteTranscript', 'toneDirectives'];

/** Filter shared pipeline state down to the Story Director's slice (drops photos, URLs, secrets, other agents' outputs). */
export function selectStoryDirectorInput(state = {}) {
  const p = state.project ?? state;
  const inputs = p.inputs ?? {};
  // The graph's top-level castDescriptions defaults to [], so `??` silently dropped inputs.castDescriptions (r4-dry11/12). Merge both.
  const castDescriptions = [...(p.castDescriptions ?? []), ...(inputs.castDescriptions ?? [])]
    .map(({ id, name, description }) => ({ id, name, description }));
  return StoryDirectorInput.parse({
    subject: inputs.subject ?? '',
    answers: inputs.answers ?? {},
    castDescriptions,
    photoCharacters: (inputs.photoReferences ?? p.photoReferences ?? [])
      .map(({ id, name, realPerson, age, skinTone, description }) => ({ id, name, realPerson: realPerson ?? name, age: age ?? null, skinTone, description })),
    format: p.format ?? {},
    ...pick(inputs, STORY_DIRECTION_KEYS),
  });
}

function pick(o, keys) { return Object.fromEntries(keys.filter(k => o[k] !== undefined).map(k => [k, o[k]])); }
