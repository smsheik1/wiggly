import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readdirSync } from 'node:fs';
import { V2_MODELS } from '../config/models.mjs';

const agents = readdirSync(new URL('../crew/', import.meta.url), { withFileTypes: true }).filter(d => d.isDirectory()).map(d => d.name);
test('every v2 crew agent has a model entry', () => {
  assert.ok(agents.length >= 6);
  for (const a of agents) assert.ok(V2_MODELS[a], `missing model entry for ${a}`);
});
test('story director: OpenRouter Haiku 5.5 at high (r5-sd10 picked it over Muse)', () => {
  assert.deepEqual([V2_MODELS['story-director'].provider, V2_MODELS['story-director'].model, V2_MODELS['story-director'].effort],
    ['openrouter', 'anthropic/claude-haiku-5.5', 'high']);
});
test('every image step is Nano Banana 2.1 via Google Flow', () => {
  let n = 0;
  for (const [a, cfg] of Object.entries(V2_MODELS)) for (const [k, img] of Object.entries(cfg.imageSteps ?? {})) {
    n++; assert.equal(img.model, 'nano-banana-2.1', `${a}.${k}`); assert.equal(img.provider, 'google-flow', `${a}.${k}`);
  }
  assert.ok(n >= 3);
  for (const k of ['storyboard', 'character', 'location']) assert.ok(Object.values(V2_MODELS).some(c => c.imageSteps?.[k]), k);
});
test('video: Seedance 2.5 480p, not yet enabled', () => {
  const v = V2_MODELS['seedance-compiler'].video;
  assert.equal(v.model, 'bytedance/seedance-2.5'); assert.equal(v.resolution, '480p'); assert.equal(v.enabled, false);
});
import { loadSkill } from '../config/models.mjs';
test('downstreamAgents and maxTokens', () => {
  assert.deepEqual(V2_MODELS['story-director'].downstreamAgents, ['character-architect', 'location-scout']);
  for (const [a, c] of Object.entries(V2_MODELS)) {
    assert.ok(Array.isArray(c.downstreamAgents), a);
    for (const d of c.downstreamAgents) assert.ok(V2_MODELS[d], `${a} -> unknown ${d}`);
    assert.ok(Number.isInteger(c.maxTokens), a);
    if (c.kind === 'llm') assert.ok(c.maxTokens > 0, a);
  }
});
test('every LLM agent output cap fits its model limit (MODEL_LIMITS), with headroom over the r5-dry1 Story Director peak', async () => {
  const { MODEL_LIMITS, outputCap } = await import('../config/models.mjs');
  for (const [a, c] of Object.entries(V2_MODELS)) {
    if (c.kind !== 'llm') continue;
    const lim = MODEL_LIMITS[c.model];
    assert.ok(lim, `${a}: no MODEL_LIMITS entry for ${c.model}`);
    assert.ok(c.maxTokens <= lim.maxCompletionTokens, a); assert.equal(outputCap(c), c.maxTokens);
  }
  assert.ok(V2_MODELS['story-director'].maxTokens >= 1.5 * 64200, 'SD cap needs headroom over the 64.2k r5-dry1 peak');
  assert.throws(() => outputCap({ model: 'meta/muse-spark-1.3-contributor', maxTokens: 2_000_000 }), /exceeds .*output limit 943718/);
});
test('loadSkill reads role.md and throws clearly when missing', () => {
  assert.match(loadSkill('story-director'), /Story Director/);
  assert.throws(() => loadSkill('nobody'), /unknown v2 agent "nobody"/);
});
test('character architect: muse xhigh, Nano Banana sheets, feeds vera + compiler, contract files exist', async () => {
  const c = V2_MODELS['character-architect'];
  assert.deepEqual([c.provider, c.model, c.effort], ['openrouter', 'meta/muse-spark-1.3-contributor', 'xhigh']);
  assert.equal(c.imageSteps.character.model, 'nano-banana-2.1');
  assert.ok(c.downstreamAgents.includes('seedance-compiler') && c.downstreamAgents.includes('vera'));
  assert.deepEqual(c.targetEngines, { masterRender: 'nano-banana-2.1', modelSheet: 'nano-banana-2.1' });
  const { existsSync } = await import('node:fs');
  for (const f of Object.values(c.contract)) assert.ok(existsSync(new URL('../' + f, import.meta.url)), f);
});
test('location scout: muse xhigh, Nano Banana plates, parallel with CA, feeds compiler, contract files exist', async () => {
  const c = V2_MODELS['location-scout'];
  assert.deepEqual([c.provider, c.model, c.effort], ['openrouter', 'meta/muse-spark-1.3-contributor', 'xhigh']);
  assert.equal(c.imageSteps.location.model, 'nano-banana-2.1');
  assert.deepEqual(c.targetEngines, { plate: 'nano-banana-2.1' });
  assert.ok(c.downstreamAgents.includes('seedance-compiler'));
  assert.deepEqual(c.parallelWith, ['character-architect']);
  const { existsSync } = await import('node:fs');
  for (const f of Object.values(c.contract)) assert.ok(existsSync(new URL('../' + f, import.meta.url)), f);
});
test('location scout: Gemini role label, 32000 tokens (8192 truncated xhigh reasoning), loadLocationScoutSkill', async () => {
  const { loadLocationScoutSkill } = await import('../config/models.mjs');
  const c = V2_MODELS['location-scout'];
  assert.equal(c.role, 'Location Scout & Environment Plate Architect'); assert.equal(c.maxTokens, 32000);
  assert.deepEqual(c.downstreamAgents, ['vera', 'seedance-compiler']);
  assert.match(loadLocationScoutSkill(), /Location Scout & Environment Plate Architect/);
});
test('seedance compiler: muse xhigh, Seedance 2.5 480p disabled, upstream CA + LS, downstream vera, contract files exist', async () => {
  const c = V2_MODELS['seedance-compiler'];
  assert.deepEqual([c.provider, c.model, c.effort], ['openrouter', 'meta/muse-spark-1.3-contributor', 'xhigh']);
  assert.deepEqual([c.video.model, c.video.resolution, c.video.enabled], ['bytedance/seedance-2.5', '480p', false]);
  assert.deepEqual(c.targetEngines, { video: 'seedance-2.5' }); assert.equal(c.segmentMaxSec, 30); assert.equal(c.continuation, 'extend');
  assert.deepEqual(c.upstreamAgents, ['character-architect', 'location-scout']);
  assert.ok(c.downstreamAgents.includes('vera'));
  for (const u of c.upstreamAgents) assert.ok(V2_MODELS[u].downstreamAgents.includes('seedance-compiler'), u);
  const { existsSync } = await import('node:fs');
  for (const f of Object.values(c.contract)) assert.ok(existsSync(new URL('../' + f, import.meta.url)), f);
  assert.match(loadSkill('seedance-compiler'), /Seedance Compiler/);
});

test('Story Director model: default unchanged, WIGGLY_SD_MODEL overrides with a known model, unknown throws', async () => {
  const { storyDirectorModel, DEFAULT_SD_MODEL, MODEL_LIMITS, V2_MODELS } = await import('../config/models.mjs');
  assert.equal(DEFAULT_SD_MODEL, 'anthropic/claude-haiku-5.5');
  assert.equal(storyDirectorModel({ WIGGLY_SD_MODEL: 'meta/muse-spark-1.3-contributor' }), 'meta/muse-spark-1.3-contributor');
  assert.equal(storyDirectorModel({}), DEFAULT_SD_MODEL);
  assert.equal(storyDirectorModel({ WIGGLY_SD_MODEL: ' ' }), DEFAULT_SD_MODEL);
  
  assert.throws(() => storyDirectorModel({ WIGGLY_SD_MODEL: 'nope/model' }), /not in MODEL_LIMITS/);
  assert.ok(V2_MODELS['story-director'].maxTokens <= MODEL_LIMITS['anthropic/claude-haiku-5.5'].maxCompletionTokens);
  if (!process.env.WIGGLY_SD_MODEL) assert.equal(V2_MODELS['story-director'].model, DEFAULT_SD_MODEL);
});
