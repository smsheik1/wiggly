# 3D Breakdown Repo

Read v3/public/format-repositories/three-d-breakdown-v1/SKILL.md and README.md first. All commands run from v3. Use the packaged runtime; never rebuild it. Run the free smoke test before real work. Planning uses your coding agent, not a separate LLM API. Paid media still requires approval.
